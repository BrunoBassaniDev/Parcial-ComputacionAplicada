#!/bin/bash
# Mostrar ayuda
if [[ "$1" == "-help" || "$1" == "--help" ]]; then
	echo "Uso: $0 <directorio_origen> <directorio_destino>"
	echo "Ejemplo: $0 /var/log /backup_dir"
	echo "El script realiza un backup comprimido del directorio origen en destino."
	exit 0
fi

# Obtener fecha en formato YYYYMMDD

FECHA=$(date +%Y%m%d)

# Parametros de entrada

ORIGEN=$1
DESTINO=$2

# Validacion basica

if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
	echo "Error: Debe indicar origen y destino."
	exit 1
fi
# Validar que existan
if [ ! -d "$ORIGEN" ]; then
	echo "Error: el directorio de origen no existe"
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: el directorio de destino no existe"
	exit 1
fi

# Nombre base del directorio origen

NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

# Crear backup

tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

echo "Backup completado: $DESTINO/$NOMBRE"
